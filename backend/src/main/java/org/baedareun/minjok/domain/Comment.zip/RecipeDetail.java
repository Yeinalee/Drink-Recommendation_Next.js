package org.baedareun.minjok.domain;

public class RecipeDetail {
}
